import threading
import xml.etree.ElementTree as xmlT
import unittest

def partition(a, l, h):
	p = l
	i = l
	j = h
	while i < j:
		while i <= h and a[i] <= a[p]:
			i += 1
		while j >= l and a[j] > a[p]:
			j -= 1
		if i < j:
			a[i], a[j] = a[j], a[i]
	a[j], a[p] = a[p], a[j]
	return j

def qsort(a, l, h):
	if l < h:
		p = partition(a, l, h)
		t1 = threading.Thread(target = qsort, args = (a, l, p-1))
		t2 = threading.Thread(target = qsort, args = (a, p+1, h))
		t1.start()
		t2.start()
		t1.join()
		t2.join()
		print t1.getName()		#name of the thread
		print t2.getName()
	return a

class MyTest(unittest.TestCase):
	def test_p1ositive(self):
		self.assertEqual(qsort([3,2,1], 0, 2), [1,2,3])

data = xmlT.parse('data.xml').getroot()
a = map(int, data.text.split())
qsort(a, 0, len(a) - 1)
for i in a:
	print i, 
print
unittest.main()