from flask import Flask , request, render_template

app = Flask(__name__)

@app.route('/')
def fun():
    return render_template('index.html',msg="")
    
@app.route('/check/',methods=['POST'])
def check():
    ab = checker(request.form['string'])
    return render_template('index.html',msg=ab)

def checker(str1):
	file_data=""
	with open("data.txt","r") as f:
		file_data=f.read()
	
	unwanted="!@#$%^&*()_+="
	for i in unwanted:
		file_data=file_data.replace(i,"")	#remove spl characters from both, file and input
		str1=str1.replace(i,"")
		
		file_data=file_data.replace("."," ") 	#Remove . from file
		a=file_data.split(" ")					#Split file with " "
		#a=a[:-1]
		print "a is:",a

		str1=str1.replace("."," ")			#Remove . from input
		b=str1.split(" ")					#Split input with " "
		print "b is:",b

		a_dict={}
		b_dict={}
		for i in a:							#Which word occurs how many times in file. Word as the key. Count as the value.
			try:
				a_dict[i]+=1
			except KeyError: 
				a_dict[i]=1
		print "a_dict"
		print a_dict

		for j in b:							#Which word occurs how many times in input. Word as the key. Count as the value.
			try:
				b_dict[j]+=1
			except KeyError:
				b_dict[j]=1
		print "b_dict"
		print b_dict
		
		count=0
		for b_key in b_dict.keys():
			if b_key in a_dict.keys():
				count+=b_dict[b_key]		#How many times a word a word appears in input.
		percentage = str(float(count)/(len(b))*100.0)+"%"
		return percentage
	
				

if __name__=="__main__":
    app.run(debug=True)
