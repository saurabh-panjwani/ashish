import json

def printBoard(board):
	for x in board: 
		print(x)

def safe(board,row,column):
	#check if queen placed at board[row][column]
	for i in range(8):
		for j in range(8):
			if board[i][j] == 1:
				if i == row or j == column:
					return False
				#check diagonals
				if abs(row-i) == abs(column-j):
					return False
	return True



def solveBoard(board,column):
	if column >= 8:						#All queens placed
		return True

	for i in range(8):				#check rows for a specific column
		if safe(board,i,column):	#if not safe, check for next row in next for iteration
			#place queen at row, column
			board[i][column] = 1
			#place rest of the queens
			if solveBoard(board, column+1):		#if column>=8 condition returns true here and this true is returned to main function
												
				return True

			#if queen is not being placed at col+1, the current queen is backtracked
			#remove queen from row, column(backtracked)
			board[i][column] = 0
			#now all the queens backtracked
			
	#if current queen not placed, it returns false to solverboard(board,column+1)
	return False

if __name__ == '__main__':
	json_data = []
	with open("input.json", "r") as json_file:
		json_data = json.load(json_file)

	#print("start position is: " + repr(json_data["start"]))
	board = [[0 for x in range(8)] for y in range(8)]
	board[json_data["start"]][0] = 1	#place queen at (0,0)
	printBoard(board)
 
	if (solveBoard(board,1) == True):	#If all the queens placed
		print("solution found")
		printBoard(board)
	else:
		print("no solution found")
