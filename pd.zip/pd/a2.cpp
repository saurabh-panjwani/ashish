//Quick Sort: Divide and conquer for concurrent quick sort

#include<iostream>
#include<pthread.h>
#include<stdlib.h>
#include<sched.h>
using namespace std;
int N;
struct args
{
int* a;
int first;
int last;
};
void swap(int& a, int& b)
{
int temp = a;
a = b;
b = temp;
}
void print(int a[], const int& N)
{
for(int i = 0 ; i < N ; i++)
cout << "array[" << i << "] = " << a[i] << endl;
}
int pivot(int a[], int first, int last)
{
int p = first;
int pivotElement = a[first];
for(int i = first+1 ; i <= last ; i++)
{
/* If you want to sort the list in the other order, change "<=" to ">" */
if(a[i] <= pivotElement)
{
p++;
swap(a[i], a[p]);
}
}
swap(a[p], a[first]);
return p;
}
void* quickSort(void* arg)
{
pthread_t id=pthread_self();
args* ar=(args*)arg;
int pivotElement;
pthread_t threads[2];
if(ar->first < ar->last)
{
pivotElement = pivot(ar->a, ar->first, ar->last);
cout<<"Thread number "<<id<<" executing on core "<<sched_getcpu()
<<"found pivotElement "<<ar->a[pivotElement]<<"\n";
args array1;
array1.a=new int[N];
array1.a=ar->a;
array1.first=ar->first;
array1.last=pivotElement-1;
args* x=&array1;
int rc = pthread_create(&threads[0], NULL, &quickSort, (void *)x);
args array2;
array2.a=new int[N];
array2.a=ar->a;
array2.first=pivotElement+1;
array2.last=ar->last;
args* y=&array2;
int rc1 = pthread_create(&threads[1], NULL, &quickSort, (void *)y);
pthread_join(threads[0], NULL);
pthread_join(threads[1], NULL);
}
}
int main()
{
cout<<"\nEnter number of elements in array:";
cin>>N;
int test[N];
cout<<"\nNow enter Array ELements: \n";
for(int i=0;i<N;i++)
{cin>>test[i];}
cout << "Before sorting : " << endl;
print(test, N);
args array;
array.a=new int[N];
array.a=test;
array.first=0;
array.last=N-1;
quickSort(&array);
cout << endl << endl << "After sorting : " << endl;
print(test, N);
return 0;
}

/*localhost@localhost:~/CL1/Group A/A2$ g++ a2.cpp -pthread
localhost@localhost:~/CL1/Group A/A2$ ./a.out
Enter number of elements in array:6

Now enter Array ELements: 
2
0
1
6
4
3
Before sorting : 
array[0] = 2
array[1] = 0
array[2] = 1
array[3] = 6
array[4] = 4
array[5] = 3
Thread number 139841620387648 executing on core 2found pivotElement 2
Thread number 139841603049216 executing on core 3found pivotElement 1
Thread number 139841594656512 executing on core 3found pivotElement 6
Thread number 139841603049216 executing on core 2found pivotElement 3


After sorting : 
array[0] = 0
array[1] = 1
array[2] = 2
array[3] = 3
array[4] = 4
array[5] = 6*/
