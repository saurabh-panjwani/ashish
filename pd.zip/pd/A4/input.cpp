#include <stdio.h>
#include <iostream.h>
#include <math.h>
main()
{
int a,b,c;
printf("Hello");
int d,e;
printf("HI");
scanf("Enter");
a=b+20;
if()
{
c=d;
char x,y;
}
}
