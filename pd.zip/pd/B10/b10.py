def prune(last_table,min_sup):

    items = last_table.keys()

    for x in items:
        if(last_table[x]<min_sup):
            last_table.pop(x,None)



def get_sup_count(db,line):
    item = line.split(',')
    num =0
    for x in db:
        if(set(item).issubset(set(x))):
            num+=1
    return num

def self_join(db,last_table,k):
    items = last_table.keys()
    last_table.clear()

    for i in xrange(len(items)):

        j= i+1

        seti = items[i].split(',')

        while j<(len(items)):

            setj = items[j].split(',')

            nset = list(set(seti)|set(setj))

            if(len(nset)==k):
                line=""
            for l in range(len(nset)-1):
                line += str(nset[l])+","
            line +=str(nset[l+1])

            last_table[line] = get_sup_count(db,line)

            j+=1


#read

files = open('transactions.csv',"r")
db=[]
last_table = {}

print files


for line in files:

    #print line+"\n"
    line = line.replace('\n','')
    fline = line.split(',')
    #print fline
    db.append(fline)



for x in db:
    for item in x:
        if(last_table.has_key(item) and item!='-'):
            last_table[item]+=1
        elif( not last_table.has_key(item) and item!='-'):
            last_table[item] = 1
    k=2

while True:
    values = last_table.values()
    keys = last_table.keys()

    if(len(keys)<1):
        break

    prune(last_table,3)

    print last_table

    self_join(db,last_table,k)

    k+=1
    
'''localhost@localhost:~/Other/b10$ python b10.py
<open file 'transactions.csv', mode 'r' at 0x7fafc9dbf5d0>
{'Keychain': 5, 'Onion': 4, 'Eggs': 4, 'Chocolate': 3, 'Mango': 3}
{'Keychain,Onion': 3, 'Keychain,Chocolate': 3, 'Eggs,Keychain': 4, 'Mango,Keychain': 3, 'Eggs,Onion': 3}
{'Eggs,Keychain,Onion': 3}
localhost@localhost:~/Other/b10$'''
