#include <iostream>
#include <math.h>

#define MAX 20

using namespace std;

int main()
{
  int k,n;
  int cnt = 0;
  int x[MAX],y[MAX],cenx[MAX],ceny[MAX],kc[MAX],kc1[MAX];
  int d[MAX],euc_dist[MAX][MAX];

  cout<<"Enter no of clusters \n";
  cin>>k;

  cout<<"ENter no of objects \n";
  cin>>n;

  for(int i=0;i<n;i++)
  {
    cout<<"Enter x cord \n";
    cin>>x[i];
    cenx[i] = x[i];

    cout<<"Enter y cord";
    cin>>y[i];
    ceny[i] = y[i];

    kc[i]=0;
    kc1[i] = 0;

  }

  do
  {
    for(int m=0;m<k;m++)
    {
      for(int j=0;j<n;j++)
      {
        d[j] = ((cenx[m]-x[j])*(cenx[m]-x[j]) + (ceny[m]-y[j])*(ceny[m]-y[j]) );
        euc_dist[m][j] = sqrt(d[j]);
      }
    }

    int l =0;

    for(int i=0;i<n;i++)
    {
      if(kc[i]==kc1[i])
      {
        l++;
      }
    }

    if(l==n)
    {
      cnt++;
    }
    else
    {
      for (int i=0;i<n;i++)
      {
        kc1[i]=kc[i];
      }
    }



    for(int j=0;j<n;j++)
    {

      int min = 999;
      for(int m=0;m<k;m++)
      {
        if(euc_dist[m][j]<min)
        {
          min = euc_dist[m][j];
          kc[j] = m;
        }
      }
      cenx[j]=ceny[j] =0;
    }


    int xcnt =0;
    for(int m=0;m<k;m++)
    {
      xcnt =0;
      for(int j=0;j<n;j++)
      {
        if(kc[j]==m)
        {
          cenx[m] += x[j];
          ceny[m] += y[j];
          xcnt++;
        }
      }
      cenx[m] = cenx[m]/xcnt;
      ceny[m] = ceny[m]/xcnt;
    }

  }while(cnt<2);

  for(int m=0;m<k;m++)
  {
    cout<<"Cluster NO "<<m<<endl;
    for (int i=0;i<n;i++)
    {
      if(kc[i]==m)
      {
        cout<<"("<<x[i]<<","<<y[i]<<")"<<endl;
      }
    }
  }
}

/*localhost@localhost:~/Other/a6$ ./a.out
Enter no of clusters 
3
ENter no of objects 
8
Enter x cord 
2
Enter y cord10
Enter x cord 
2
Enter y cord5
Enter x cord 
8
Enter y cord4
Enter x cord 
5
Enter y cord8
Enter x cord 
7
Enter y cord5
Enter x cord 
6
Enter y cord4
Enter x cord 
1
Enter y cord2
Enter x cord 
4
Enter y cord9
Cluster NO 0
(2,10)
(5,8)
(4,9)
Cluster NO 1
(2,5)
(1,2)
Cluster NO 2
(8,4)
(7,5)
(6,4)
localhost@localhost:~/Other/a6$*/
