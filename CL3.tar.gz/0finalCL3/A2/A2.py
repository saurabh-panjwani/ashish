import xml.etree.ElementTree as X
import threading
import unittest

def partition(a,low,high):
	pIndex=low
	pivot=a[high]
	for i in range(low,high):
		if(a[i]<pivot):
			a[i],a[pIndex]=a[pIndex],a[i]
			pIndex=pIndex+1
	a[pIndex],a[high]=a[high],a[pIndex]
	return pIndex

def quicksort(a,low,high):
	if low<high:	
		p=partition(a,low,high)
		
		t1=threading.Thread(target=quicksort,args=[a,p+1,high])
		t2=threading.Thread(target=quicksort,args=[a,low,p-1])
		t1.start()
		t1.join()
		print (t1.getName())
		t2.start()
		t2.join()
		print (t2.getName())
		return a
	else: 
		return -1


r=X.parse('input.xml').getroot()
a=map(int,r.text.split())
print a
a=quicksort(a,0,len(a)-1)
print a

class Test(unittest.TestCase):
	def test_positive(self):
		return self.assertEqual(quicksort([10,5,60,4,6],0,4),[4,5,6,10,60])
	def test_negative(self):
		return self.assertEqual(quicksort([10,5,60,4,6],4,3),-1)

unittest.main()
