from flask import *
from plag import *

app=Flask(__name__)

@app.route('/')
def Mainpage():
	return render_template('index.html',msg=None)

@app.route('/eval',methods=['POST','GET'])
def second():
	m=plag(request.form['string'])
	return render_template('index.html',msg=m)

app.run()

