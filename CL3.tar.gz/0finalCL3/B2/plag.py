
def plag(str1):
	file_data=""
	with open('input.txt') as f:
		for line in f: 
			file_data = file_data + line
	
	a=file_data.split('.')
	b=str1.split('.')
	
	for i in range(len(a)):
		a[i]=a[i].strip()
	for j in range(len(b)):
		b[j]=b[j].strip()
	
	print a
	print b
	count=0	
	for i in range(len(b)-1):
		for j in range(len(a)-1):	
			if(a[j]==b[i]):
				count=count+1
	percent=(float(count)/(len(b)-1))*100
	return percent
