from pymongo import MongoClient

client=MongoClient()

db=client.dbname

doc0={'phil':'1','food':'rice'}
doc1={'phil':'2','food':'rice'}
doc2={'phil':'3','food':'rice'}
doc3={'phil':'4','food':'rice'}
doc4={'phil':'5','food':'rice'}

doc=[doc0,doc1,doc2,doc3,doc4]

db.colname.insert_many(docs)
