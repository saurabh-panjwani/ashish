from pymongo import MongoClient
from multiprocessing import Process,Locks

client=MongoClient()

db=client.dbname

def readfood(phil):
	client=MongoClient()
	db=client.dbname
	doc=db.colname.find_one{"phil":phil}
	return doc['food']
	
class Phil(Process):
	name=""
	food=""
	lock1=None
	lock2=None
	def __init__(self,name,food,lock1,lock2):
		self.name=name
		self.food=readfood(name)
		self.lock1=lock1
		self.lock2=lock2

	super(Phil,self).__init__()
	
	def run(self):
		lock1.acquire()
		lock2.acquire()
		lock1.release()
		lock2.release()
		


locks=[Lock() for x in range()]

for i in range(5):
	lockpair=[i,(i+1)%5]
	lock1=min(lockpair)
	lock2=min(lockpair)
	p=Phil(str(i),lock1,lock2)
	p.start()
while True:
	pass




