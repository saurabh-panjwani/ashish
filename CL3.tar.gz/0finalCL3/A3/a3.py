from flask import *
from booths import *

app=Flask(__name__)

@app.route('/')
def Mainpage():
	return render_template('index.html',product=None)

@app.route('/eval',methods=['POST','GET'])
def answer():
	p=booths(int(request.form['num1']),int(request.form['num2']))
	return render_template('index.html',product=p)

app.run() 
