def d2b(x):
	a=[0]*8
	i=7
	while(i>=0):
		a[i]=x%2
		x=x/2
		i=i-1
	return a

def add(x,y):
	z=[0]*17
	i=16
	c=0
	while(i>=0):
		temp=x[i]+y[i]+c
		z[i]=temp%2
		c=temp/2
		i=i-1
	return z

def rightshift(x):
	i=16
	while(i>=1):
		x[i]=x[i-1]
		i=i-1
	return x
def sub(x,y):
	z=[0]*16
	i=15
	c=0
	while(i>=1):
		temp=x[i]-y[i]-c
		z[i]=temp%2
		c=abs(temp/2)
		i=i-1
	return z

def b2d(x):	
	if(x[0]==1):
		one=[0]*15+[1]
		print "Normal x:",x
		print "One:",one
		x=sub(x,one)
		print "Subtracted X:",x
		i=15		
		while(i>=0):
			x[i]=1-x[i]
			i=i-1
		print "-X:", x
	ans=0
	p=0
	i=15
	while(i>=1):
		if(x[i]==1):
			ans=ans+2**p
		p=p+1
		i=i-1
	if(x[0]==1):
		return -ans
	else:
		return ans	
	
def booths(x,y):
	M=d2b(x)
	print "M is:", M
	Q=d2b(y)
	print "Q is:", Q
	minus_M=d2b(-x)
	print "-M is:", minus_M
	P=[0]*8
	P.extend(Q)
	P.append(0)
	print "P is:",P
	M += [0]*9
	print "New M is:", M
	minus_M += [0]*9
	print "New -M is:", minus_M
	for i in range(8):
		if(P[-2]==1 and P[-1]==0):
			P=add(P,minus_M)
			print "P-M: ", P
		elif(P[-2]==0 and P[-1]==1):
			P=add(P,M)
			print "P+M:", P
		P=rightshift(P)
		print "Rightshifted P:",P
	P=P[:-1]
	return b2d(P)
