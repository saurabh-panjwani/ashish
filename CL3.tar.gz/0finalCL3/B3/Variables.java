package com.example.root.calculator;

public class Variables {
    static String operation;
}
