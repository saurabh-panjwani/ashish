from flask import *
import os

app=Flask(__name__)

@app.route('/')
def Mainpage():
	return render_template('index.html')

@app.route('/add',methods=['POST','GET'])
def add():
	os.system('./dropbox_uploader.sh mkdir newdir')
	return render_template('index.html')

@app.route('/list',methods=['POST','GET'])
def list():
	os.system('./dropbox_uploader.sh list')
	return render_template('index.html')

@app.route('/upload',methods=['POST','GET'])
def upload():
	os.system('./dropbox_uploader.sh upload /home/rohit/a.txt /newdir/')
	return render_template('index.html')

@app.route('/download',methods=['POST','GET'])
def download():
	os.system('./dropbox_uploader.sh download newdir/a.txt /home/rohit/')
	return render_template('index.html')

@app.route('/delete',methods=['POST','GET'])
def delete():
	os.system('./dropbox_uploader.sh delete newdir')
	return render_template('index.html')

app.run()
