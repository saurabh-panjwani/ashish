import json
import unittest

def isAttack(board,row,col):
	for i in range(8):
		if(board[i][col]==1):
			return True
	i=row-1
	j=col-1
	while(i>=0 and j>=0):
		if(board[i][j]==1):
			return True		
		i=i-1
		j=j-1
	i=row-1
	j=col+1
	while(i>=0 and j<=7):
		if(board[i][j]==1):
			return True
		i=i-1
		j=j+1
	return False


def isSolve(board,row):
	i=0
	for i in range(8):
		if(not isAttack(board,row,i)):
			board[row][i]=1
			if(row==7):
				return True
			else:
				if(isSolve(board,row+1)):
					return True
				else:
					board[row][i]=0
		if(i==8):
			return False

def queens(filename):
	board=[[0 for x in range(8)]for x in range (8)]
	data =[]
	with open(filename) as f:
		data=json.load(f)
	if ((data['start'] < 0) or (data['start'] > 7)):
		#exit()
		return -1
	#board[0][data['start']]=1
	for z in range(8):
		board=[[0 for x in range(8)]for x in range (8)]
		print "initial pos:",z
		board[0][z]=1
		if(isSolve(board,1)):
			for i in range(8):
				for j in range(8):
					print board[i][j],
				print ("\n")
	return 1

queens('input.json')


class Test(unittest.TestCase):
	def test_positive(self):
		return self.assertEqual(queens('input.json'),1)
	def test_negative(self):
		return self.assertEqual(queens('input1.json'),-1)

unittest.main()
