import xml.etree.ElementTree as X
import unittest

def binarysearch(a,low,high,key):
	if(low<=high):
		mid=low+(high-low)/2
		if(a[mid]==key):
			print "Element found at:",mid+1
			return mid+1
		elif(a[mid]>key):
			return binarysearch(a,low,mid-1,key)
		else:
			return binarysearch(a,mid+1,high,key)
	else:
		print "Element not found"
		return -1



'''
size=int(input("Enter the no. of elements to be put in the array:"))
a=[]
for i in range(0,size):
	x=int(input("Enter element"))
	a.append(x)
'''
r=X.parse('input.xml').getroot()
a=map(int,r.text.split())
print a
a.sort()
print a
key=int(input("enter the element to be searched"))

pos=binarysearch(a,0,len(a)-1,key)

class Test(unittest.TestCase):
	def test_positive(self):
		print "Checking for a=[10,20,30,40,50,60] key 50"
		self.assertEqual(binarysearch([10,20,30,40,50,60],0,5,50),5)
	def test_negative(self):
		print "Checking for a=[10,20,30,40,50,60] key 55"
		self.assertEqual(binarysearch([10,20,30,40,50,60],0,5,55),-1)

unittest.main()

