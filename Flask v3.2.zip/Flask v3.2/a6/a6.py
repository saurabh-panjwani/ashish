def cipher(ptext,key=None):
	if key is not None:
		ctext=""
		for symbol in ptext:
			if symbol.isalpha():
				num=ord(symbol)+key
				if symbol.isupper():
					if(num>ord('Z')):
						num=num-26
					elif num<ord('A'):
						num=num+26
				elif symbol.islower():
					if(num>ord('z')):
						num=num-26
					elif num<ord('a'):
						num=num+26
				ctext+=chr(num)
			else:
				ctext+=symbol
		return ctext

	else:
		a="abcdefghijklmnopqrstuvwxyz"
		b="qwertyuiopasdfghjklzxcvbnm"
		ctext=""
		for symbol in ptext:
			if symbol.isalpha():
				if symbol.islower():
					index=a.find(symbol)
					num=b[index]
					ctext+=num
				elif symbol.isupper():
					index=a.find(symbol.tolower())
					num=b[index]
					ctext+=num.toupper()
			else:
				ctext+=symbol
		return ctext



if __name__=="__main__":
	ptext=raw_input("enter message")
	choice=int(raw_input("1.caesar 2.monoalphabetic"))

	if choice==1:
		key=int(raw_input("enter key"))
		ctext=cipher(ptext,key)
		print "cipher text is ",ctext
	elif choice==2:
		ctext=cipher(ptext)
		print "cipher text is ",ctext
	else:
		print "wrong choice"
	
