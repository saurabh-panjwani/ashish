from pymongo import MongoClient
import threading
from threading import Thread
import time

class Philosophers(Thread):
	connection=MongoClient("localhost",27017)

	def __init__(self,index,name,leftfork,rightfork):
		Thread.__init__(self)
		self.index=index
		self.name=name
		self.leftfork=leftfork
		self.rightfork=rightfork

	def read_from_mongo(self,index):
		db=self.connection.dini.testraw
		cursor=db.find({"ph_no":index})
		print (cursor[0])
	
	def run(self):
		while self.running==True:
			time.sleep(6)
			print "phil %d is hungry"%self.index
			self.din()

	def din(self):
		fork1=self.leftfork
		fork2=self.rightfork

		while self.running==True:	
			fork1.acquire(True)
			val=fork2.acquire(False)
			if val:
				break
			fork1.release()
			fork1,fork2=fork2,fork1
		else:
			return
		self.dine()
		fork1.release()
		fork2.release()

	def dine(self):
		print "phil %d is eating"%self.index
		self.read_from_mongo(self.index)
		time.sleep(6)
		print "phil %d finished eating"%self.index



def main():
	fork=[]
	for i in range(5):
		fork.append(threading.Lock())
	names=["a","b","c","d","e"]

	phils=[]
	for i in range(5):	
		phils.append(Philosophers(i,names[i],fork[i%5],fork[(i+1)%5]))

	Philosophers.running=True

	for p in phils:
		p.start()

	time.sleep(10)
	Philosophers.running=False

main()

