from pymongo import MongoClient

connection=MongoClient("localhost",27017)

db=connection.dini.testraw

f=open("data.txt").read().strip().split("\n")

for line in f:
	line=line.strip().split(",")
	post={"ph_no":int(line[0]),"index":int(line[1])}
	db.insert(post)
