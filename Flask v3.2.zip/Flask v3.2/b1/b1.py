import json

inf=open("data.json")
board=json.loads(inf.read())
board=board["matrix"]


def issafe(row,col):
	for i in range(8):
		for j in range(8):
			if board[i][j]==1:
				if i==row:
					return False
				if j==col:
					return False
				if abs(row-i)==abs(col-j):
					return False
	return True

def place2(col):
	if col>=8:
		print "soln found"
		return True
	for i in range(8):
		if(issafe(i,col)):	
			board[i][col]=1
			if(place2(col+1)):
				return True
			board[i][col]=0
	return False


if(place2(1))==True:
	for i in range(8):
	
		print board[i]
		
	print "successful"
else:
	print "no soln"
