from flask import *

app=Flask(__name__)

@app.route("/")

def fun():
	return render_template('index.html',msg=" ")

@app.route("/check",methods=["POST","GET"])

def ch():
	ans=checker(request.form['string'])
	return render_template('index.html',msg=ans)

def checker(stri):
	file_data=""
	with open("data.txt") as f:
		file_data=f.read()
	unwanted="!@#$%^&*;:"

	for char in unwanted:
		file_data=file_data.replace(char," ")
		stri=stri.replace(char," ")
	file_data=file_data.replace("."," ")
	stri=stri.replace("."," ")

	a=file_data.split()
	b=stri.split()

	a_dict={}
	b_dict={}

	for a_i in a:
		try:
			a_dict[a_i]+=1
		except KeyError:
			a_dict[a_i]=1
	for b_i in b:
		try:
			b_dict[b_i]+=1
		except KeyError:
			b_dict[b_i]=1

	counter=0
	for key in b_dict.keys():
		if key in a_dict.keys():
			counter+=b_dict[key]

	ans=str((float((counter*100.0))/(len(b))))
	return ans

if __name__=="__main__":
	app.run()
