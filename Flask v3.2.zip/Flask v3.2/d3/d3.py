import random
import hashlib

def isprime(num):
	if num<2:
		return False
	if not (num & 1) :
		return False
	if num==2:
		return False
	for i in range(3,int(pow(num,0.5))+1,2):
		if num%2==0:
			return False
	return True

def get_g(h,p,q):
	for g in range(1,p):
		if pow(g,q)%p!=0 or (pow(h,(p-1)/q))%p!=0:
			g=g+1
		else:
			break
	return g

def is_compat(p,q):
	if not isprime(p):
		print "p is not prime"
		return False
	if not isprime(q):
		print "q is not prime"
		return False
	if (p-1)%q!=0:
		print "p is not prime factor of q"
		return False
	return True


print "enter message "
msg=raw_input()
m=hashlib.sha1()
m.update(msg)

print "m.hexdigest : ",m.hexdigest()

h=int(m.hexdigest(),16)


while True:
	p=int(raw_input("enter p"))
	q=int(raw_input("enter q"))
	if not is_compat(p,q):
		print "try again"
	else:
		break
g=get_g(h,p,q)

while True:
	print "enter x 1<x<q "
	x=int(raw_input())
	if x>q or x<1:
		print "enter valid x"
	else :
		break

y=pow(g,x)%p

k=random.randint(1,q)

r=(pow(g,k)%p)%q

i=0
while True:
	if (k*i)%q!=1:
		i+=1
	else:
		break

s=i*(h+r*x)

w=0
while True:
	if (s*w)%q!=1:
		w+=1
	else:
		break

u1=(h*w)%q
u2=(r*w)%q

v=((pow(g,u1)*pow(y,u2))%p)%q


if v==r:
	print "verification successful"
else:
	print "verification unsuccessful"
