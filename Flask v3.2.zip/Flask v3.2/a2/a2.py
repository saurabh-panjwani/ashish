import xml.etree.ElementTree as xmlT
import threading
import time
from threading import Thread


def partition(a,l,h):
	p=l
	i=l
	j=h
	while i<j:
		while i<=h and a[i]<=a[p]:
			i+=1
		while j>=l and a[j]>a[p]:
			j-=1
		if i<j:
			a[i],a[j]=a[j],a[i]
	a[j],a[p]=a[p],a[j]
	return j

def quicksort(a,l,h):
	if l<h:
		p=partition(a,l,h)
		t1=threading.Thread(target=quicksort, args=(a,l,p-1))
		t2=threading.Thread(target=quicksort , args=(a,p+1,h))
		t1.start()
		t2.start()
		t1.join()
		t2.join()
		print t1.getName()
		print t2.getName()
	return a


def main():
	data=xmlT.parse("data.xml").getroot()
	a=map(int,data.text.split())
	a=quicksort(a,0,len(a)-1)
	print a

main()
