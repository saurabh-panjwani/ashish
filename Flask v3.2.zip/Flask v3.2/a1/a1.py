import unittest

class MyTestCases(unittest.TestCase):
	def test_pos(self):
		binary_obj=Binary_search([5,4,6,3,7],5)
		self.assertEqual(binary_obj.perform_binary_search(),2)
	def test_neg(self):
		binary_obj=Binary_search([5,4,6,3,7],8)
		self.assertEqual(binary_obj.perform_binary_search(),5)

class Binary_search:
	def __init__(self,a,key):
		self.a=a
		self.key=key
		self.sort_i()
		print self.a

	def sort_i(self):
		self.a.sort()


	def bin_s(self,left,right):
		mid=(left+right)/2
		if mid>right or mid<left:
			return len(self.a)

		elif self.a[mid]==self.key:
			return mid

		elif self.a[mid]>self.key:
			right=mid-1
		elif self.a[mid]<self.key:
			left=mid+1
		return self.bin_s(left,right)		

	def perform_binary_search(self):
		index=self.bin_s(0,len(self.a)-1)
		if index>=len(self.a):
			print "element not found"
		else:
			print "element at pos ",index
		return index

def main():
	print "enter elements"
	a=map(int,raw_input().split())
	print "enter key"
	key=int(raw_input().strip())

	binary_obj=Binary_search(a,key)
	index=binary_obj.perform_binary_search()

main()
unittest.main()
