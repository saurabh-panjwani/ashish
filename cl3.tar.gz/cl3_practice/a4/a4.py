import time
import threading
from pymongo import MongoClient
import random

class Philosophers(threading.Thread):
	running=True
	connection = MongoClient("127.0.0.1",27017)

	def __init__(self,name,i,left,right):
		threading.Thread.__init__(self)
		self.name=name
		self.right=right
		self.left=left
		self.index=i

	def readFromMongo(self,index):
		print "Reading raw data...."
		db = Philosophers.connection.test.diniraw
		cursor = db.find({"ph_no": index})
		print(cursor[0])
	
	def run(self):
		while(self.running):
			time.sleep(random.uniform(1,10))
			print ("%s is hungry"%self.name)
			self.dine()

	def dine(self):
		fork1,fork2=self.left,self.right
		while(self.running):
			fork1.acquire(True)
			locked=fork2.acquire(False)
			if locked:
				break
			fork1.release()
			print ("%s swapping forks"%self.name)
			fork1,fork2=fork2,fork1
		else:
			return

		self.dining()
		fork1.release()
		fork2.release()

	def dining(self):
		print ("%s is eating finally"%self.name)
		Philosophers.readFromMongo(self,self.index)
		time.sleep(random.uniform(3,10))
		print ("%s is done eating, back to thinking"%self.name)

def diningPhilosophers():
	forks=[threading.Lock() for n in range(5)]
	philosopherNames=('Anmol','Desale','Pallya','Lekhya','Dhirya')
	philosophers=[]

	for i in range(5):
		philosophers.append(Philosophers(philosopherNames[i], i, forks[i%5], forks[(i+1)%5]))
	random.seed(50456)
	Philosophers.running=True
	
	for philosopher in philosophers:
		philosopher.start()
	time.sleep(50)

	Philosophers.running=False
	print "Done eating"

diningPhilosophers()
