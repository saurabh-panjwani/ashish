package com.example.anmol.calc;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {
    Button b0,b1,b2,b3,b4,b5,b6,b7,b8,b9,b_add,b_sub,b_mul,b_div,b_sin,b_perc,b_root,b_eq,b_cl,b_rec;
    TextView t1,v1;
    int val1,val2,val3;
    char p='+';
    char s='-';
    char m='*';
    char d='/';
    boolean add,sub,div,mul;
    ArrayList<Integer> res = new ArrayList<Integer>(10);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b0 = (Button) findViewById(R.id.button0);
        b1 = (Button) findViewById(R.id.button1);
        b2 = (Button) findViewById(R.id.button2);
        b3 = (Button) findViewById(R.id.button3);
        b4 = (Button) findViewById(R.id.button4);
        b5 = (Button) findViewById(R.id.button5);
        b6 = (Button) findViewById(R.id.button6);
        b7 = (Button) findViewById(R.id.button7);
        b8 = (Button) findViewById(R.id.button8);
        b9 = (Button) findViewById(R.id.button9);
        b_add = (Button) findViewById(R.id.button_add);
        b_sub= (Button) findViewById(R.id.button_sub);
        b_mul = (Button) findViewById(R.id.button_multiply);
        b_div = (Button) findViewById(R.id.button_divide);
        b_sin = (Button) findViewById(R.id.button_sin);
        b_perc = (Button) findViewById(R.id.button_perc);
        b_root = (Button) findViewById(R.id.button_root);
        b_eq = (Button)findViewById(R.id.button_eq);
        b_cl= (Button) findViewById(R.id.button_clear);
        b_rec = (Button) findViewById(R.id.button_show);
        t1 = (TextView) findViewById(R.id.ans);
        v1 = (TextView) findViewById(R.id.textView);

        b_rec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int size=res.size();
                for(int i=0; i<size; i++){
                    v1.setText(v1.getText() + " " + res.get(i) + " , ");
                }

            }
        });

        b_cl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                t1.setText("");
            }
        });

        b_root.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                val1=Integer.parseInt(t1.getText()+"");
                t1.setText(Math.sqrt(val1)+"");
            }
        });
        b_sin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                val1=Integer.parseInt(t1.getText()+"");
                t1.setText(Math.sin(val1)+"");
            }
        });


        b0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                t1.setText(t1.getText()+"0");
                res.add(0);
            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                t1.setText(t1.getText()+"1");
                res.add(1);
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                t1.setText(t1.getText()+"2");
                res.add(2);
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                t1.setText(t1.getText()+"3");
                res.add(3);
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                t1.setText(t1.getText()+"4");
                res.add(4);
            }
        });
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                t1.setText(t1.getText()+"5");
            }
        });
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                t1.setText(t1.getText()+"6");
            }
        });
        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                t1.setText(t1.getText()+"7");
            }
        });
        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                t1.setText(t1.getText()+"8");
            }
        });
        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                t1.setText(t1.getText()+"9");
            }
        });
        b_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                val1=Integer.parseInt(t1.getText()+"");
                add=true;
                t1.setText(null);
            }
        });
        b_sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                val1=Integer.parseInt(t1.getText()+"");
                sub=true;
                t1.setText(null);
            }
        });
        b_mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                val1=Integer.parseInt(t1.getText()+"");
                mul=true;
                t1.setText(null);
            }
        });
        b_div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                val1=Integer.parseInt(t1.getText()+"");
                div=true;
                t1.setText(null);
            }
        });
        b_eq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                val2=Integer.parseInt(t1.getText()+"");
                if (add==true){
                    val3=val1+val2;
                    t1.setText(val3+"");
                    res.add(Integer.valueOf(p));
                    res.add(val3);
                    add=false;
                }
                if (sub==true){
                    val3=val1-val2;
                    t1.setText(val3+"");
                    res.add(Integer.valueOf(s));
                    res.add(val3);
                    sub=false;
                }
                if (mul==true){
                    val3=val1*val2;
                    t1.setText(val3+"");
                    res.add(Integer.valueOf(m));
                    res.add(val3);
                    mul=false;
                }
                if (div==true){
                    val3=val1/val2;
                    t1.setText(val3+"");
                    res.add(val3);
                    div=false;
                }
            }
        });
    }
}
