import json
import unittest

class MyTest(unittest.TestCase):
	def test(self):
		self.assertEqual(func("input.json"),True)
	

def printBoard(board):
	for x in board: 
		print(x)

def safe(board,row,column):
	for i in range(8):
		for j in range(8):
			if board[i][j] == 1:
				if i == row or j == column:
					return False
				if abs(row-i) == abs(column-j):
					return False
	return True

def solveBoard(board,column):
	if column >= 8:
		return True
	for i in range(8):
		if safe(board,i,column):
			board[i][column] = 1
			if solveBoard(board, column+1):
				return True
			board[i][column] = 0
	return False

def func(filename):
	data= []
	with open(filename, "r") as jfile:
		data = json.load(jfile)

	print("start position is: " + repr(data["start"]))
	board = [[0 for x in range(8)] for y in range(8)]
	board[data["start"]][0] = 1
	printBoard(board)

	if (solveBoard(board,1) == True):
		print("solution found")
		printBoard(board)
		return True
	else:
		print("no solution found")
		return False
unittest.main()
