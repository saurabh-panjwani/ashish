import unittest

class MyTestCases(unittest.TestCase):
	def test_positive(self):
		binSearchObj = BinarySearch([10, 15, 30, 20, 19], 19)
		self.assertEqual(binSearchObj.perform_binary_search(),2)

	def test_negative(self):
		binSearchObj = BinarySearch([6, 8, 21, 34, 12],20)
		self.assertEqual(binSearchObj.perform_binary_search(),5)


class BinarySearch:
	def __init__(self, a, key):
		self.a=a
		self.key=key
		self.display()
		self.sort()

	def display(self):
		print "The list is",self.a

	def sort(self):
		self.a.sort()

	def binary_search(self,a,left,right):
		mid=(left+right)/2
		if mid>right or mid<left:
			return len(self.a)
		elif a[mid]==self.key:
			return mid
		elif a[mid]<self.key:
			left=mid+1
		elif a[mid]>self.key:
			right=mid-1
		return self.binary_search(a,left,right)

	def perform_binary_search(self):
		a=self.a
		left=0
		right=len(self.a)-1
		index = self.binary_search(a,left,right)
		if (index>=len(self.a)):
			print "Not found"
		else:
			print "Element found at ",index+1, "in the list",self.a
		return index
	

def main():
	print "Enter elements."
	a=map(int, raw_input().split())
	print "List is created.\n"
	key=int(raw_input("Enter searching element\n").strip())
	binSearchObj = BinarySearch(a,key)
	binSearchObj.perform_binary_search()

print "Executing code"
main()
print "\nTesting"
unittest.main()
