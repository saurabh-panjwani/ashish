import unittest

class MyTest(unittest.TestCase):
	def pos(self):
		binobj=BinarySearch([20,10,3,12,15],3)
		self.assertEqual(binobj.perform_binary_search,0)

class BinarySearch:
	def __init__(self,a,key):
		self.a=a
		self.key=key
		self.display()
		self.sort()
	
	def sort():
		self.a.sort()

	def display():
		print "List: ",self.a

	def binary_search(self,a,left,right):
		mid=(left+right)/2
		if mid<left or mid>right:
			return len(self.a)
		elif a[key]==mid:
			return a[key]
		elif a[key]<mid:
			right=mid-1
		elif a[key]>mid:
			left=mid+1
		return binary_search(a,left,right)

	def perform_binary_search(a,l,r):
		self.a=a
		l=0
		r=len(a)-1
		index = binary_seach(a,l,r)
		if index>len(a):
			return "Not found"
		else:
			print "Found at: "+index+1
		return index	
	
	def main():
		print "Enter elements: "
		a=map(int,raw_input().split())
		key=int(raw_input("Enter key: ").strip())
		binobj = BinarySearch(a,key)
		binobj.perform_binary_seach()

unittest.main()
