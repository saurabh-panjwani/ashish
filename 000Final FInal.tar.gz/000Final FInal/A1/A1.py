import os
import unittest

def read(filename):
	f=open(filename,'r')
	arr=[]
	for element in f:
		arr.append(int(element))
	return (arr)

def search(key,lst,first,last):
	if(first<=last):	
		mid=(last+first)/2
		if(key==lst[mid]):
			return mid
		elif(key<lst[mid]):
			return search(key,lst,first,mid-1)
		elif(key>lst[mid]):
			return search(key,lst,mid+1,last)
		
class Test(unittest.TestCase):
	def test_postive(self):
		self.assertEqual(search(1,[0,1,2,3,4,5],0,5),1)
	def test_negative(self):
		self.assertEqual(search(10,[0,1,2,3,4,5],0,5),None)
	
array=read("input.txt")
print "Input Array is :",array
array.sort()
print "Sorted Array is :",array
x=input("\nEnter the key to be searched\t")
ind=search(x,array,0,len(array)-1)
print("Value found at index : ",ind)
print("Unit testing :")
unittest.main() 
