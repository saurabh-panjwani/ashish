#!/usr/bin/python
import os
import sys

def createf():
	os.system("./dropbox_uploader.sh mkdir newdir")

def listf():
	os.system("./dropbox_uploader.sh list")
	
def uploadf():
	os.system("./dropbox_uploader.sh upload /home/akshay/a.txt /newdir/")
	
def downloadf():
	os.system("./dropbox_uploader.sh download /a.txt /home/akshay/dropdown")

def deletef():
	os.system("./dropbox_uploader.sh delete /newdir")
